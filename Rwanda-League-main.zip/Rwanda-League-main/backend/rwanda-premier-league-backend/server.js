const app = require('./app');
const connectDB = require('./config/db');
const http = require('http');
const { Server } = require('socket.io');

// Connect to database
connectDB();

const server = http.createServer(app);

const io = new Server(server, {
    cors: {
        origin: process.env.CLIENT_URL || 'http://localhost:3000',
        methods: ['GET', 'POST']
    }
});

// Socket.io connection
io.on('connection', socket => {
    console.log('New client connected');

    // Join match room
    socket.on('joinMatch', matchId => {
        socket.join(matchId);
        console.log(`User joined match ${matchId}`);
    });

    // Live match updates
    socket.on('matchUpdate', data => {
        io.to(data.matchId).emit('matchUpdate', data);
    });

    // Disconnect
    socket.on('disconnect', () => {
        console.log('Client disconnected');
    });
});

const PORT = process.env.PORT || 5000;

server.listen(PORT, () => {
    console.log(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`.yellow.bold);
});

// Handle unhandled promise rejections
process.on('unhandledRejection', (err, promise) => {
    console.log(`Error: ${err.message}`.red);
    // Close server & exit process
    server.close(() => process.exit(1));
});