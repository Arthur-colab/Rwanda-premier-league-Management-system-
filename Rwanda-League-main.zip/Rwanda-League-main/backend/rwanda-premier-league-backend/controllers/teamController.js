const Team = require('../models/Team');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const cloudinary = require('../utils/cloudinary');

// @desc    Get all teams
// @route   GET /api/v1/teams
// @access  Public
exports.getTeams = asyncHandler(async (req, res, next) => {
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over removeFields and delete them from reqQuery
    removeFields.forEach(param => delete reqQuery[param]);

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

    // Finding resource
    query = Team.find(JSON.parse(queryStr));

    // Select fields
    if (req.query.select) {
        const fields = req.query.select.split(',').join(' ');
        query = query.select(fields);
    }

    // Sort
    if (req.query.sort) {
        const sortBy = req.query.sort.split(',').join(' ');
        query = query.sort(sortBy);
    } else {
        query = query.sort('name');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await Team.countDocuments();

    query = query.skip(startIndex).limit(limit);

    // Executing query
    const teams = await query;

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
        pagination.next = {
            page: page + 1,
            limit
        };
    }

    if (startIndex > 0) {
        pagination.prev = {
            page: page - 1,
            limit
        };
    }

    res.status(200).json({
        success: true,
        count: teams.length,
        pagination,
        data: teams
    });
});

// @desc    Get single team
// @route   GET /api/v1/teams/:id
// @access  Public
exports.getTeam = asyncHandler(async (req, res, next) => {
    const team = await Team.findById(req.params.id);

    if (!team) {
        return next(
            new ErrorResponse(`Team not found with id of ${req.params.id}`, 404)
        );
    }

    res.status(200).json({
        success: true,
        data: team
    });
});

// @desc    Create new team
// @route   POST /api/v1/teams
// @access  Private/Admin
exports.createTeam = asyncHandler(async (req, res, next) => {
    // Upload image to cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
        folder: 'rwanda-premier-league/teams',
        width: 500,
        crop: 'scale'
    });

    const team = await Team.create({
        ...req.body,
        logo: {
            public_id: result.public_id,
            url: result.secure_url
        }
    });

    res.status(201).json({
        success: true,
        data: team
    });
});

// @desc    Update team
// @route   PUT /api/v1/teams/:id
// @access  Private/Admin
exports.updateTeam = asyncHandler(async (req, res, next) => {
    let team = await Team.findById(req.params.id);

    if (!team) {
        return next(
            new ErrorResponse(`Team not found with id of ${req.params.id}`, 404)
        );
    }

    // Check if new image is uploaded
    if (req.file) {
        // Delete old image from cloudinary
        await cloudinary.uploader.destroy(team.logo.public_id);

        // Upload new image
        const result = await cloudinary.uploader.upload(req.file.path, {
            folder: 'rwanda-premier-league/teams',
            width: 500,
            crop: 'scale'
        });

        team = await Team.findByIdAndUpdate(
            req.params.id,
            {
                ...req.body,
                logo: {
                    public_id: result.public_id,
                    url: result.secure_url
                }
            },
            {
                new: true,
                runValidators: true
            }
        );
    } else {
        team = await Team.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
    }

    res.status(200).json({
        success: true,
        data: team
    });
});

// @desc    Delete team
// @route   DELETE /api/v1/teams/:id
// @access  Private/Admin
exports.deleteTeam = asyncHandler(async (req, res, next) => {
    const team = await Team.findById(req.params.id);

    if (!team) {
        return next(
            new ErrorResponse(`Team not found with id of ${req.params.id}`, 404)
        );
    }

    // Delete image from cloudinary
    await cloudinary.uploader.destroy(team.logo.public_id);

    await team.remove();

    res.status(200).json({
        success: true,
        data: {}
    });
});