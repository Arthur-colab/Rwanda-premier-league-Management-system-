const Fixture = require('../models/Fixture');
const Team = require('../models/Team');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');

// @desc    Get all fixtures
// @route   GET /api/v1/fixtures
// @route   GET /api/v1/teams/:teamId/fixtures
// @access  Public
exports.getFixtures = asyncHandler(async (req, res, next) => {
    if (req.params.teamId) {
        const fixtures = await Fixture.find({
            $or: [
                { homeTeam: req.params.teamId },
                { awayTeam: req.params.teamId }
            ]
        })
            .populate('homeTeam', 'name shortName logo')
            .populate('awayTeam', 'name shortName logo')
            .sort('matchDate');

        return res.status(200).json({
            success: true,
            count: fixtures.length,
            data: fixtures
        });
    } else {
        res.status(200).json(res.advancedResults);
    }
});

// @desc    Get single fixture
// @route   GET /api/v1/fixtures/:id
// @access  Public
exports.getFixture = asyncHandler(async (req, res, next) => {
    const fixture = await Fixture.findById(req.params.id)
        .populate('homeTeam', 'name shortName logo')
        .populate('awayTeam', 'name shortName logo');

    if (!fixture) {
        return next(
            new ErrorResponse(`Fixture not found with id of ${req.params.id}`, 404)
        );
    }

    res.status(200).json({
        success: true,
        data: fixture
    });
});

// @desc    Create new fixture
// @route   POST /api/v1/fixtures
// @access  Private/Admin
exports.createFixture = asyncHandler(async (req, res, next) => {
    // Check if teams are different
    if (req.body.homeTeam === req.body.awayTeam) {
        return next(
            new ErrorResponse('Home team and away team cannot be the same', 400)
        );
    }

    // Check if teams exist
    const homeTeam = await Team.findById(req.body.homeTeam);
    const awayTeam = await Team.findById(req.body.awayTeam);

    if (!homeTeam || !awayTeam) {
        return next(new ErrorResponse('One or both teams not found', 404));
    }

    const fixture = await Fixture.create(req.body);

    res.status(201).json({
        success: true,
        data: fixture
    });
});

// @desc    Update fixture
// @route   PUT /api/v1/fixtures/:id
// @access  Private/Admin
exports.updateFixture = asyncHandler(async (req, res, next) => {
    let fixture = await Fixture.findById(req.params.id);

    if (!fixture) {
        return next(
            new ErrorResponse(`Fixture not found with id of ${req.params.id}`, 404)
        );
    }

    // Check if teams are different
    if (req.body.homeTeam && req.body.awayTeam && req.body.homeTeam === req.body.awayTeam) {
        return next(
            new ErrorResponse('Home team and away team cannot be the same', 400)
        );
    }

    // Check if teams exist
    if (req.body.homeTeam) {
        const homeTeam = await Team.findById(req.body.homeTeam);
        if (!homeTeam) {
            return next(new ErrorResponse('Home team not found', 404));
        }
    }

    if (req.body.awayTeam) {
        const awayTeam = await Team.findById(req.body.awayTeam);
        if (!awayTeam) {
            return next(new ErrorResponse('Away team not found', 404));
        }
    }

    fixture = await Fixture.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
        runValidators: true
    });

    res.status(200).json({
        success: true,
        data: fixture
    });
});

// @desc    Delete fixture
// @route   DELETE /api/v1/fixtures/:id
// @access  Private/Admin
exports.deleteFixture = asyncHandler(async (req, res, next) => {
    const fixture = await Fixture.findById(req.params.id);

    if (!fixture) {
        return next(
            new ErrorResponse(`Fixture not found with id of ${req.params.id}`, 404)
        );
    }

    await fixture.remove();

    res.status(200).json({
        success: true,
        data: {}
    });
});

// @desc    Get fixtures by status
// @route   GET /api/v1/fixtures/status/:status
// @access  Public
exports.getFixturesByStatus = asyncHandler(async (req, res, next) => {
    const fixtures = await Fixture.find({ status: req.params.status })
        .populate('homeTeam', 'name shortName logo')
        .populate('awayTeam', 'name shortName logo')
        .sort('matchDate');

    res.status(200).json({
        success: true,
        count: fixtures.length,
        data: fixtures
    });
});

// @desc    Get fixtures by matchday
// @route   GET /api/v1/fixtures/matchday/:matchday
// @access  Public
exports.getFixturesByMatchday = asyncHandler(async (req, res, next) => {
    const fixtures = await Fixture.find({ matchday: req.params.matchday })
        .populate('homeTeam', 'name shortName logo')
        .populate('awayTeam', 'name shortName logo')
        .sort('matchDate');

    res.status(200).json({
        success: true,
        count: fixtures.length,
        data: fixtures
    });
});