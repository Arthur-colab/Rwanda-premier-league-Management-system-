const News = require('../models/News');
const ErrorResponse = require('../utils/errorResponse');
const asyncHandler = require('../middleware/async');
const cloudinary = require('../utils/cloudinary');

// @desc    Get all news
// @route   GET /api/v1/news
// @access  Public
exports.getNews = asyncHandler(async (req, res, next) => {
    let query;

    // Copy req.query
    const reqQuery = { ...req.query };

    // Fields to exclude
    const removeFields = ['select', 'sort', 'page', 'limit'];

    // Loop over removeFields and delete them from reqQuery
    removeFields.forEach(param => delete reqQuery[param]);

    // Create query string
    let queryStr = JSON.stringify(reqQuery);

    // Create operators ($gt, $gte, etc)
    queryStr = queryStr.replace(/\b(gt|gte|lt|lte|in)\b/g, match => `$${match}`);

    // Finding resource
    query = News.find(JSON.parse(queryStr))
        .populate('author', 'name email');

    // Select fields
    if (req.query.select) {
        const fields = req.query.select.split(',').join(' ');
        query = query.select(fields);
    }

    // Sort
    if (req.query.sort) {
        const sortBy = req.query.sort.split(',').join(' ');
        query = query.sort(sortBy);
    } else {
        query = query.sort('-createdAt');
    }

    // Pagination
    const page = parseInt(req.query.page, 10) || 1;
    const limit = parseInt(req.query.limit, 10) || 10;
    const startIndex = (page - 1) * limit;
    const endIndex = page * limit;
    const total = await News.countDocuments();

    query = query.skip(startIndex).limit(limit);

    // Executing query
    const news = await query;

    // Pagination result
    const pagination = {};

    if (endIndex < total) {
        pagination.next = {
            page: page + 1,
            limit
        };
    }

    if (startIndex > 0) {
        pagination.prev = {
            page: page - 1,
            limit
        };
    }

    res.status(200).json({
        success: true,
        count: news.length,
        pagination,
        data: news
    });
});

// @desc    Get single news
// @route   GET /api/v1/news/:id
// @access  Public
exports.getNewsItem = asyncHandler(async (req, res, next) => {
    const news = await News.findById(req.params.id).populate('author', 'name email');

    if (!news) {
        return next(
            new ErrorResponse(`News not found with id of ${req.params.id}`, 404)
        );
    }

    // Increment views count
    news.views += 1;
    await news.save();

    res.status(200).json({
        success: true,
        data: news
    });
});

// @desc    Create news
// @route   POST /api/v1/news
// @access  Private/Admin
exports.createNews = asyncHandler(async (req, res, next) => {
    // Add user to req.body
    req.body.author = req.user.id;

    // Upload image to cloudinary
    const result = await cloudinary.uploader.upload(req.file.path, {
        folder: 'rwanda-premier-league/news',
        width: 1200,
        crop: 'scale'
    });

    const news = await News.create({
        ...req.body,
        image: {
            public_id: result.public_id,
            url: result.secure_url
        }
    });

    res.status(201).json({
        success: true,
        data: news
    });
});

// @desc    Update news
// @route   PUT /api/v1/news/:id
// @access  Private/Admin
exports.updateNews = asyncHandler(async (req, res, next) => {
    let news = await News.findById(req.params.id);

    if (!news) {
        return next(
            new ErrorResponse(`News not found with id of ${req.params.id}`, 404)
        );
    }

    // Make sure user is news owner or admin
    if (news.author.toString() !== req.user.id && req.user.role !== 'admin') {
        return next(
            new ErrorResponse(
                `User ${req.user.id} is not authorized to update this news`,
                401
            )
        );
    }

    // Check if new image is uploaded
    if (req.file) {
        // Delete old image from cloudinary
        await cloudinary.uploader.destroy(news.image.public_id);

        // Upload new image
        const result = await cloudinary.uploader.upload(req.file.path, {
            folder: 'rwanda-premier-league/news',
            width: 1200,
            crop: 'scale'
        });

        news = await News.findByIdAndUpdate(
            req.params.id,
            {
                ...req.body,
                image: {
                    public_id: result.public_id,
                    url: result.secure_url
                }
            },
            {
                new: true,
                runValidators: true
            }
        );
    } else {
        news = await News.findByIdAndUpdate(req.params.id, req.body, {
            new: true,
            runValidators: true
        });
    }

    res.status(200).json({
        success: true,
        data: news
    });
});

// @desc    Delete news
// @route   DELETE /api/v1/news/:id
// @access  Private/Admin
exports.deleteNews = asyncHandler(async (req, res, next) => {
    const news = await News.findById(req.params.id);

    if (!news) {
        return next(
            new ErrorResponse(`News not found with id of ${req.params.id}`, 404)
        );
    }

    // Make sure user is news owner or admin
    if (news.author.toString() !== req.user.id && req.user.role !== 'admin') {
        return next(
            new ErrorResponse(
                `User ${req.user.id} is not authorized to delete this news`,
                401
            )
        );
    }

    // Delete image from cloudinary
    await cloudinary.uploader.destroy(news.image.public_id);

    await news.remove();

    res.status(200).json({
        success: true,
        data: {}
    });
});

// @desc    Get featured news
// @route   GET /api/v1/news/featured
// @access  Public
exports.getFeaturedNews = asyncHandler(async (req, res, next) => {
    const news = await News.find({ isFeatured: true })
        .sort('-createdAt')
        .limit(3)
        .populate('author', 'name email');

    res.status(200).json({
        success: true,
        count: news.length,
        data: news
    });
});