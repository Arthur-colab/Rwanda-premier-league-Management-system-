const express = require('express');
const {
    getNews,
    getNewsItem,
    createNews,
    updateNews,
    deleteNews,
    getFeaturedNews
} = require('../controllers/newsController');
const { protect, authorize } = require('../middleware/auth');

const router = express.Router();

router.route('/').get(getNews).post(protect, authorize('admin'), createNews);
router.route('/featured').get(getFeaturedNews);
router
    .route('/:id')
    .get(getNewsItem)
    .put(protect, authorize('admin'), updateNews)
    .delete(protect, authorize('admin'), deleteNews);

module.exports = router;