const express = require('express');
const {
    getTeams,
    getTeam,
    createTeam,
    updateTeam,
    deleteTeam
} = require('../controllers/teamController');
const { protect, authorize } = require('../middleware/auth');
const advancedResults = require('../middleware/advancedResults');
const Team = require('../models/Team');

const router = express.Router();

router
    .route('/')
    .get(advancedResults(Team), getTeams)
    .post(createTeam);

router
    .route('/:id')
    .get(getTeam)
    .put(protect, authorize('admin'), updateTeam)
    .delete(protect, authorize('admin'), deleteTeam);

module.exports = router;