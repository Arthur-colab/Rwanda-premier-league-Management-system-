const express = require('express');
const {
    getFixtures,
    getFixture,
    createFixture,
    updateFixture,
    deleteFixture,
    getFixturesByStatus,
    getFixturesByMatchday
} = require('../controllers/fixtureController');
const { protect, authorize } = require('../middleware/auth');
const advancedResults = require('../middleware/advancedResults');
const Fixture = require('../models/Fixture');

const router = express.Router();

router
    .route('/')
    .get(
        advancedResults(Fixture, [
            { path: 'homeTeam', select: 'name shortName logo' },
            { path: 'awayTeam', select: 'name shortName logo' }
        ]),
        getFixtures
    )
    .post(protect, authorize('admin'), createFixture);

router
    .route('/:id')
    .get(getFixture)
    .put(protect, authorize('admin'), updateFixture)
    .delete(protect, authorize('admin'), deleteFixture);

router.route('/status/:status').get(getFixturesByStatus);
router.route('/matchday/:matchday').get(getFixturesByMatchday);

// Re-route into team router
const teamRouter = require('./teamRoutes');
router.use('/teams/:teamId/fixtures', teamRouter);

module.exports = router;