const mongoose = require('mongoose');

const teamSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, 'Please enter team name'],
        unique: true,
        trim: true,
        maxlength: [50, 'Team name cannot exceed 50 characters']
    },
    shortName: {
        type: String,
        required: [true, 'Please enter team short name'],
        maxlength: [10, 'Short name cannot exceed 10 characters']
    },
    founded: {
        type: Number,
        required: [true, 'Please enter founding year']
    },
    stadium: {
        type: String,
        required: [true, 'Please enter stadium name']
    },
    location: {
        type: String,
        required: [true, 'Please enter team location'],
        enum: ['kigali', 'south', 'west', 'north', 'east']
    },
    coach: {
        type: String,
        required: [true, 'Please enter coach name']
    },
    logo: {
        public_id: {
            type: String,
            required: true
        },
        url: {
            type: String,
            required: true
        }
    },
    website: {
        type: String,
        validate: {
            validator: function (v) {
                return /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/.test(v);
            },
            message: props => `${props.value} is not a valid website URL!`
        }
    },
    socialMedia: {
        twitter: String,
        facebook: String,
        instagram: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('Team', teamSchema);