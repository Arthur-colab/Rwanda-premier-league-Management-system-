const mongoose = require('mongoose');

const newsSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Please enter news title'],
        trim: true,
        maxlength: [100, 'News title cannot exceed 100 characters']
    },
    content: {
        type: String,
        required: [true, 'Please enter news content']
    },
    excerpt: {
        type: String,
        required: [true, 'Please enter news excerpt'],
        maxlength: [200, 'Excerpt cannot exceed 200 characters']
    },
    author: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    image: {
        public_id: {
            type: String,
            required: true
        },
        url: {
            type: String,
            required: true
        }
    },
    tags: [{
        type: String
    }],
    category: {
        type: String,
        enum: ['match', 'transfer', 'interview', 'general'],
        default: 'general'
    },
    isFeatured: {
        type: Boolean,
        default: false
    },
    views: {
        type: Number,
        default: 0
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

module.exports = mongoose.model('News', newsSchema);