const mongoose = require('mongoose');

const fixtureSchema = new mongoose.Schema({
    homeTeam: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Team',
        required: [true, 'Please select home team']
    },
    awayTeam: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Team',
        required: [true, 'Please select away team']
    },
    matchDate: {
        type: Date,
        required: [true, 'Please enter match date']
    },
    matchTime: {
        type: String,
        required: [true, 'Please enter match time']
    },
    venue: {
        type: String,
        required: [true, 'Please enter match venue']
    },
    matchday: {
        type: Number,
        required: [true, 'Please enter matchday number']
    },
    status: {
        type: String,
        enum: ['scheduled', 'ongoing', 'completed', 'postponed', 'cancelled'],
        default: 'scheduled'
    },
    homeScore: {
        type: Number,
        default: null
    },
    awayScore: {
        type: Number,
        default: null
    },
    referee: {
        type: String
    },
    attendance: {
        type: Number
    },
    highlights: {
        type: String
    },
    createdAt: {
        type: Date,
        default: Date.now
    }
});

// Prevent duplicate fixtures
fixtureSchema.index({ homeTeam: 1, awayTeam: 1, matchDate: 1 }, { unique: true });

module.exports = mongoose.model('Fixture', fixtureSchema);