// Dashboard navigation functionality
document.addEventListener('DOMContentLoaded', function () {
    const navLinks = document.querySelectorAll('.dashboard-nav a');
    const sections = document.querySelectorAll('.dashboard-section');

    navLinks.forEach(link => {
        link.addEventListener('click', function (e) {
            e.preventDefault();

            // Remove active class from all links
            navLinks.forEach(navLink => navLink.classList.remove('active'));
            // Add active class to clicked link
            this.classList.add('active');

            const targetId = this.getAttribute('href');

            // Hide all sections
            sections.forEach(section => {
                section.style.display = 'none';
            });

            // Show target section
            document.querySelector(targetId).style.display = 'block';
        });
    });

    // Follow team buttons
    const followButtons = document.querySelectorAll('.btn-follow');
    followButtons.forEach(button => {
        button.addEventListener('click', function () {
            const teamCard = this.closest('.team-card');
            const teamName = teamCard.querySelector('h3').textContent;

            if (this.classList.contains('followed')) {
                this.classList.remove('followed');
                this.innerHTML = '<i class="far fa-star"></i> Follow';
                alert(`You unfollowed ${teamName}`);
            } else {
                this.classList.add('followed');
                this.innerHTML = '<i class="fas fa-star"></i> Following';
                alert(`You are now following ${teamName}`);
            }
        });
    });

    // Unfollow team buttons in dashboard
    const unfollowButtons = document.querySelectorAll('.btn-unfollow');
    unfollowButtons.forEach(button => {
        button.addEventListener('click', function () {
            const teamItem = this.closest('.team-item');
            const teamName = teamItem.querySelector('h4').textContent;

            if (confirm(`Are you sure you want to unfollow ${teamName}?`)) {
                teamItem.remove();
                alert(`You unfollowed ${teamName}`);
            }
        });
    });

    // Add team button
    const addTeamBtn = document.querySelector('.btn-add-team');
    if (addTeamBtn) {
        addTeamBtn.addEventListener('click', function () {
            // In a real app, this would open a modal to select teams to follow
            alert('This would open a team selection modal');
        });
    }

    // Buy tickets button
    const buyTicketsBtn = document.querySelector('.btn-buy-tickets');
    if (buyTicketsBtn) {
        buyTicketsBtn.addEventListener('click', function (e) {
            e.preventDefault();
            // In a real app, this would redirect to tickets page
            alert('Redirecting to tickets page would go here');
            window.location.href = 'fixtures.html';
        });
    }

    // View ticket buttons
    const viewTicketBtns = document.querySelectorAll('.btn-view-ticket');
    viewTicketBtns.forEach(button => {
        button.addEventListener('click', function () {
            // In a real app, this would show ticket details
            alert('Showing ticket details would go here');
        });
    });

    // Refresh button
    const refreshBtn = document.querySelector('.btn-refresh');
    if (refreshBtn) {
        refreshBtn.addEventListener('click', function () {
            // In a real app, this would refresh dashboard data
            alert('Refreshing dashboard data would go here');
        });
    }

    // Edit profile button
    const editProfileBtn = document.querySelector('.btn-edit-profile');
    if (editProfileBtn) {
        editProfileBtn.addEventListener('click', function (e) {
            e.preventDefault();
            // In a real app, this would open profile edit modal
            alert('Profile edit modal would open here');
        });
    }
});