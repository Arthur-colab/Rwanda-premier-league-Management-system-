// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function () {
    const mobileMenuBtn = document.querySelector('.mobile-menu');
    const nav = document.querySelector('nav');

    mobileMenuBtn.addEventListener('click', function () {
        nav.classList.toggle('active');
    });

    // Close mobile menu when clicking on a link
    const navLinks = document.querySelectorAll('nav ul li a');
    navLinks.forEach(link => {
        link.addEventListener('click', function () {
            nav.classList.remove('active');
        });
    });

    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();

            const targetId = this.getAttribute('href');
            if (targetId === '#') return;

            const targetElement = document.querySelector(targetId);
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth'
                });
            }
        });
    });

    // Login button functionality
    const loginBtn = document.querySelector('.btn-login');
    if (loginBtn) {
        loginBtn.addEventListener('click', function (e) {
            e.preventDefault();
            window.location.href = 'auth.html';
        });
    }

    // Logout button functionality
    const logoutBtn = document.querySelector('.btn-logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function (e) {
            e.preventDefault();
            // In a real app, this would log the user out
            alert('Logout functionality would go here');
            window.location.href = 'index.html';
        });
    }

    // Newsletter form submission
    const newsletterForm = document.querySelector('.newsletter-form');
    if (newsletterForm) {
        newsletterForm.addEventListener('submit', function (e) {
            e.preventDefault();
            const email = this.querySelector('input[type="email"]').value;
            // In a real app, this would send the email to your backend
            alert(`Thank you for subscribing with ${email}!`);
            this.reset();
        });
    }
});

// Fixtures filter functionality
document.addEventListener('DOMContentLoaded', function () {
    const filterButtons = document.querySelectorAll('.filter-btn');
    const fixtures = document.querySelectorAll('.match-fixture');

    if (filterButtons.length > 0 && fixtures.length > 0) {
        filterButtons.forEach(button => {
            button.addEventListener('click', function () {
                // Remove active class from all buttons
                filterButtons.forEach(btn => btn.classList.remove('active'));
                // Add active class to clicked button
                this.classList.add('active');

                const filter = this.getAttribute('data-filter');

                fixtures.forEach(fixture => {
                    if (filter === 'all') {
                        fixture.style.display = 'flex';
                    } else if (fixture.classList.contains(filter)) {
                        fixture.style.display = 'flex';
                    } else {
                        fixture.style.display = 'none';
                    }
                });
            });
        });
    }

    // Matchday selector functionality
    const matchdaySelector = document.getElementById('matchday-selector');
    if (matchdaySelector) {
        matchdaySelector.addEventListener('change', function () {
            // In a real app, this would filter fixtures by matchday
            alert(`Filtering by Matchday ${this.value} would go here`);
        });
    }
});

// Teams search and filter functionality
document.addEventListener('DOMContentLoaded', function () {
    const teamSearch = document.getElementById('team-search');
    const teamLocation = document.getElementById('team-location');
    const teamCards = document.querySelectorAll('.team-card');

    if (teamSearch && teamCards.length > 0) {
        teamSearch.addEventListener('input', filterTeams);
    }

    if (teamLocation && teamCards.length > 0) {
        teamLocation.addEventListener('change', filterTeams);
    }

    function filterTeams() {
        const searchTerm = teamSearch.value.toLowerCase();
        const locationFilter = teamLocation.value;

        teamCards.forEach(card => {
            const teamName = card.querySelector('h3').textContent.toLowerCase();
            const teamLocation = card.getAttribute('data-location');

            const nameMatch = teamName.includes(searchTerm);
            const locationMatch = locationFilter === 'all' || teamLocation === locationFilter;

            if (nameMatch && locationMatch) {
                card.style.display = 'block';
            } else {
                card.style.display = 'none';
            }
        });
    }
});